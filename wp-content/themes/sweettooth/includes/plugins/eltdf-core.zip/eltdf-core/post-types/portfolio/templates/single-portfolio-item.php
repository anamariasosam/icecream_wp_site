<?php

get_header();

sweettooth_elated_get_title();

eltdf_core_get_single_portfolio();

get_footer();