<?php

include_once ELATED_CORE_SHORTCODES_PATH.'/countdown/functions.php';
include_once ELATED_CORE_SHORTCODES_PATH.'/countdown/countdown.php';