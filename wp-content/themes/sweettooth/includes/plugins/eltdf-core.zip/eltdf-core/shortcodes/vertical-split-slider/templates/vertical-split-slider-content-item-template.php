<div class="eltdf-vss-ms-section" <?php echo sweettooth_elated_get_inline_attrs($content_data); ?> <?php sweettooth_elated_inline_style($content_style);?>>
	<?php echo do_shortcode($content); ?>
</div>