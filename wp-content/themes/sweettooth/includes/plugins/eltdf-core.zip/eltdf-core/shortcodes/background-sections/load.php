<?php

include_once ELATED_CORE_SHORTCODES_PATH.'/background-sections/functions.php';
include_once ELATED_CORE_SHORTCODES_PATH.'/background-sections/background-sections.php';