<?php

include_once ELATED_CORE_SHORTCODES_PATH.'/inner-row/functions.php';
include_once ELATED_CORE_SHORTCODES_PATH.'/inner-row/inner-row-holder.php';
include_once ELATED_CORE_SHORTCODES_PATH.'/inner-row/inner-row-column.php';