<?php

include_once ELATED_CORE_SHORTCODES_PATH.'/gallery-blocks/functions.php';
include_once ELATED_CORE_SHORTCODES_PATH.'/gallery-blocks/gallery-blocks.php';