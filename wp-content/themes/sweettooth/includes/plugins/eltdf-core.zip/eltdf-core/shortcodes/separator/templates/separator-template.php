<div class="eltdf-separator-holder clearfix  <?php echo esc_attr($separator_class); ?>">
	<div class="eltdf-separator" <?php echo sweettooth_elated_get_inline_style($separator_style); ?>></div>
</div>
