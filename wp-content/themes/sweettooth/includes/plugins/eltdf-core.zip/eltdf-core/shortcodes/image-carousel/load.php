<?php

include_once ELATED_CORE_SHORTCODES_PATH.'/image-carousel/functions.php';
include_once ELATED_CORE_SHORTCODES_PATH.'/image-carousel/image-carousel.php';
include_once ELATED_CORE_SHORTCODES_PATH.'/image-carousel/image-carousel-item.php';