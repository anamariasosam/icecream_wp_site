<div class="eltdf-image-carousel <?php echo esc_attr($slider_classes); ?>">
	<div class="eltdf-owl-slider"  <?php echo sweettooth_elated_get_inline_attrs($slider_data); ?>>
		<?php echo do_shortcode($content); ?>
	</div>
</div>