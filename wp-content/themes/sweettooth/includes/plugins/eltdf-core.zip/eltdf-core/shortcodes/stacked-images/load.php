<?php

include_once ELATED_CORE_SHORTCODES_PATH.'/stacked-images/functions.php';
include_once ELATED_CORE_SHORTCODES_PATH.'/stacked-images/stacked-images.php';
