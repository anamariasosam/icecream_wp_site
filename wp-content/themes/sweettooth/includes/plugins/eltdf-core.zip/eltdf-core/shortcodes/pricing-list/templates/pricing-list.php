<div class="eltdf-pricing-list clearfix">
	<div class="eltdf-pl-wrapper">
		<?php echo do_shortcode($content); ?>
	</div>
</div>